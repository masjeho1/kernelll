#define UTS_MACHINE		"aarch64"
#define LINUX_COMPILE_BY	"root"
#define LINUX_COMPILE_HOST	"fv-az550-672"
#define LINUX_COMPILER		"aarch64-none-linux-gnu-gcc (Arm GNU Toolchain 12.2.Rel1 (Build arm-12.24)) 12.2.1 20221205, GNU ld (Arm GNU Toolchain 12.2.Rel1 (Build arm-12.24)) 2.39.0.20221210"
