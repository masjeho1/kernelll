/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Copyright (C) 2012 ARM Ltd.
 */
#ifndef _ASM_VERMAGIC_H
#define _ASM_VERMAGIC_H

#define MODULE_ARCH_VERMAGIC	"aarch64"

#endif /* _ASM_VERMAGIC_H */
